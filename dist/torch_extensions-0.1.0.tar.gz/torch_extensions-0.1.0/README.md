Extensions for PyTorch

No more importing or converting thousands of repos into every project